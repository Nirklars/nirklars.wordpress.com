Custom preset for Minecraft TerrainControl Bukkit mod

Forum thread:
http://dev.bukkit.org/server-mods/terrain-control/forum/36269-nirklars-skylands-preset-with-download/

Please visit http://nirklars.wordpress.com!
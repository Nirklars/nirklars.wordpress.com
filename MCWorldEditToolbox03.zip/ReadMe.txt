Minecraft WorldEditTool - Remote Selection
Written by Nicklas Hult

http://nirklars.wordpress.com
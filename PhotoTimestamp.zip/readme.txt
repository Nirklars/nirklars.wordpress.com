Simple timestamp adding using batch and ImageMagick
By Nicklas H
http://nirklars.wordpress.com



The attached file convert.exe and identify.exe belongs to ImageMagick and is Open Source software
ImageMagick license notice: http://www.imagemagick.org/script/license.php
Simple html gallery maker using VBScript
By Nicklas H
http://nirklars.wordpress.com

Update 2015-06-11
-Added msdos short paths to avoid unicode letter errors


The attached file mogrify.exe belongs to ImageMagick and is Open Source software
ImageMagick license notice: http://www.imagemagick.org/script/license.php
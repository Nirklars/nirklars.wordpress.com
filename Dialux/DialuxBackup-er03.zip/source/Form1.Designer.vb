﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.btReadDialuxTitle = New System.Windows.Forms.Button()
        Me.txtDialuxPath = New System.Windows.Forms.TextBox()
        Me.lbExists = New System.Windows.Forms.Label()
        Me.txtBackupFolderPath = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btSave = New System.Windows.Forms.Button()
        Me.btReset = New System.Windows.Forms.Button()
        Me.btOpenFolder = New System.Windows.Forms.Button()
        Me.lbBackupFolder = New System.Windows.Forms.Label()
        Me.lbNumBackups = New System.Windows.Forms.Label()
        Me.txtLog = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Systray = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.btClose = New System.Windows.Forms.Button()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.ReadDIALuxToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ShowToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btClear = New System.Windows.Forms.Button()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 300000
        '
        'btReadDialuxTitle
        '
        Me.btReadDialuxTitle.Location = New System.Drawing.Point(12, 53)
        Me.btReadDialuxTitle.Name = "btReadDialuxTitle"
        Me.btReadDialuxTitle.Size = New System.Drawing.Size(156, 23)
        Me.btReadDialuxTitle.TabIndex = 0
        Me.btReadDialuxTitle.Text = "Read DIALux and Backup"
        Me.btReadDialuxTitle.UseVisualStyleBackColor = True
        '
        'txtDialuxPath
        '
        Me.txtDialuxPath.Location = New System.Drawing.Point(12, 27)
        Me.txtDialuxPath.Name = "txtDialuxPath"
        Me.txtDialuxPath.Size = New System.Drawing.Size(658, 20)
        Me.txtDialuxPath.TabIndex = 1
        '
        'lbExists
        '
        Me.lbExists.AutoSize = True
        Me.lbExists.Location = New System.Drawing.Point(174, 58)
        Me.lbExists.Name = "lbExists"
        Me.lbExists.Size = New System.Drawing.Size(89, 13)
        Me.lbExists.TabIndex = 3
        Me.lbExists.Text = "Status: Unknown"
        '
        'txtBackupFolderPath
        '
        Me.txtBackupFolderPath.Location = New System.Drawing.Point(12, 121)
        Me.txtBackupFolderPath.Name = "txtBackupFolderPath"
        Me.txtBackupFolderPath.Size = New System.Drawing.Size(658, 20)
        Me.txtBackupFolderPath.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 11)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(89, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "DIALux File Path:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 105)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Backup folder path:"
        '
        'btSave
        '
        Me.btSave.Location = New System.Drawing.Point(12, 147)
        Me.btSave.Name = "btSave"
        Me.btSave.Size = New System.Drawing.Size(75, 23)
        Me.btSave.TabIndex = 2
        Me.btSave.Text = "Save"
        Me.btSave.UseVisualStyleBackColor = True
        '
        'btReset
        '
        Me.btReset.Location = New System.Drawing.Point(93, 147)
        Me.btReset.Name = "btReset"
        Me.btReset.Size = New System.Drawing.Size(75, 23)
        Me.btReset.TabIndex = 3
        Me.btReset.Text = "Reset"
        Me.btReset.UseVisualStyleBackColor = True
        '
        'btOpenFolder
        '
        Me.btOpenFolder.Location = New System.Drawing.Point(174, 147)
        Me.btOpenFolder.Name = "btOpenFolder"
        Me.btOpenFolder.Size = New System.Drawing.Size(103, 23)
        Me.btOpenFolder.TabIndex = 4
        Me.btOpenFolder.Text = "Open Folder"
        Me.btOpenFolder.UseVisualStyleBackColor = True
        '
        'lbBackupFolder
        '
        Me.lbBackupFolder.AutoSize = True
        Me.lbBackupFolder.Location = New System.Drawing.Point(12, 182)
        Me.lbBackupFolder.Name = "lbBackupFolder"
        Me.lbBackupFolder.Size = New System.Drawing.Size(89, 13)
        Me.lbBackupFolder.TabIndex = 10
        Me.lbBackupFolder.Text = "Status: Unknown"
        '
        'lbNumBackups
        '
        Me.lbNumBackups.AutoSize = True
        Me.lbNumBackups.Location = New System.Drawing.Point(12, 403)
        Me.lbNumBackups.Name = "lbNumBackups"
        Me.lbNumBackups.Size = New System.Drawing.Size(168, 13)
        Me.lbNumBackups.TabIndex = 11
        Me.lbNumBackups.Text = "Number of backup files: Unknown"
        '
        'txtLog
        '
        Me.txtLog.Location = New System.Drawing.Point(12, 232)
        Me.txtLog.Multiline = True
        Me.txtLog.Name = "txtLog"
        Me.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtLog.Size = New System.Drawing.Size(658, 168)
        Me.txtLog.TabIndex = 12
        Me.txtLog.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 216)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(25, 13)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Log"
        '
        'Systray
        '
        Me.Systray.Text = "NotifyIcon1"
        Me.Systray.Visible = True
        '
        'btClose
        '
        Me.btClose.Location = New System.Drawing.Point(567, 406)
        Me.btClose.Name = "btClose"
        Me.btClose.Size = New System.Drawing.Size(103, 23)
        Me.btClose.TabIndex = 14
        Me.btClose.Text = "Exit Program"
        Me.btClose.UseVisualStyleBackColor = True
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ReadDIALuxToolStripMenuItem, Me.ShowToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(206, 70)
        '
        'ReadDIALuxToolStripMenuItem
        '
        Me.ReadDIALuxToolStripMenuItem.Name = "ReadDIALuxToolStripMenuItem"
        Me.ReadDIALuxToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.ReadDIALuxToolStripMenuItem.Text = "Read DIALux and Backup"
        '
        'ShowToolStripMenuItem
        '
        Me.ShowToolStripMenuItem.Name = "ShowToolStripMenuItem"
        Me.ShowToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.ShowToolStripMenuItem.Text = "Show"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(205, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'btClear
        '
        Me.btClear.Location = New System.Drawing.Point(486, 406)
        Me.btClear.Name = "btClear"
        Me.btClear.Size = New System.Drawing.Size(75, 23)
        Me.btClear.TabIndex = 15
        Me.btClear.Text = "Clear Log"
        Me.btClear.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(691, 443)
        Me.Controls.Add(Me.btClear)
        Me.Controls.Add(Me.btClose)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtLog)
        Me.Controls.Add(Me.lbNumBackups)
        Me.Controls.Add(Me.lbBackupFolder)
        Me.Controls.Add(Me.btOpenFolder)
        Me.Controls.Add(Me.btReset)
        Me.Controls.Add(Me.btSave)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtBackupFolderPath)
        Me.Controls.Add(Me.txtDialuxPath)
        Me.Controls.Add(Me.btReadDialuxTitle)
        Me.Controls.Add(Me.lbExists)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.ShowInTaskbar = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "DialuxBackup-er V0.3 by Nicklas Hult"
        Me.WindowState = System.Windows.Forms.FormWindowState.Minimized
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents btReadDialuxTitle As System.Windows.Forms.Button
    Friend WithEvents txtDialuxPath As System.Windows.Forms.TextBox
    Friend WithEvents lbExists As System.Windows.Forms.Label
    Friend WithEvents txtBackupFolderPath As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btSave As System.Windows.Forms.Button
    Friend WithEvents btReset As System.Windows.Forms.Button
    Friend WithEvents btOpenFolder As System.Windows.Forms.Button
    Friend WithEvents lbBackupFolder As System.Windows.Forms.Label
    Friend WithEvents lbNumBackups As System.Windows.Forms.Label
    Friend WithEvents txtLog As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Systray As System.Windows.Forms.NotifyIcon
    Friend WithEvents btClose As System.Windows.Forms.Button
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents ShowToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReadDIALuxToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btClear As System.Windows.Forms.Button

End Class

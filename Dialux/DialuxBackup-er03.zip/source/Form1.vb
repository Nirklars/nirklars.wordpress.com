﻿
Public Class Form1
    Dim DialuxPath As String
    Dim AppFolder = My.Application.Info.DirectoryPath
    Dim BackupFolderPath
    Dim NumberOfNackups As Integer
    Dim BackupFiles As Object

    Public Function Log(ByVal Message As String)
        txtLog.Text = Date.Now.ToString & " " & Message & vbNewLine & txtLog.Text
    End Function

    Public Sub CountBackupFiles()
        BackupFiles = My.Computer.FileSystem.GetFiles(BackupFolderPath)
        NumberOfNackups = CStr(BackupFiles.Count)
        lbNumBackups.Text = "Number of backup files: " & NumberOfNackups
        Log("Counted number of files to " & NumberOfNackups)
    End Sub

    Public Sub DeleteOldBackups()

        Dim oFileCollection
        Dim oFile
        Dim iDaysOld, iFileDaysOld As Date
        Dim result As Integer
        Dim iFileSize, iPrevFileSize As Long
        'Set file age deletion
        iDaysOld = DateAdd(DateInterval.Day, -2, Date.Now)
        oFileCollection = My.Computer.FileSystem.GetFiles(BackupFolderPath)

        For Each oFile In oFileCollection
            'Determine file age
            iFileDaysOld = My.Computer.FileSystem.GetFileInfo(oFile).LastWriteTime.Date
            result = Date.Compare(iFileDaysOld, iDaysOld)
            'Determine file size
            iFileSize = My.Computer.FileSystem.GetFileInfo(oFile).Length

            'Delete if too old
            If result <= 0 Then
                My.Computer.FileSystem.DeleteFile(oFile.ToString)
                Log("File " & oFile.ToString & " deleted.")
            Else
            End If

            'Remove duplicate
            If iFileSize = iPrevFileSize Then
                My.Computer.FileSystem.DeleteFile(oFile.ToString)
                Log("File " & oFile.ToString & " duplicate deleted.")
            Else
            End If

            'Set this check to next
            iPrevFileSize = iFileSize
        Next

        oFileCollection = Nothing
        oFile = Nothing


        'If NumberOfNackups > 3 Then
        'MsgBox(BackupFiles)
        'oFolder = oFSO.GetFolder(sDirectoryPath)
        'End If
    End Sub

    Public Sub MakeBackupOfFile()
        Try
            Dim Datestamp, FileDestination As String

            'Set filename to date
            Datestamp = Date.Today.Year & Date.Today.Month & Date.Today.Day & TimeOfDay.Hour & TimeOfDay.Minute & TimeOfDay.Second
            FileDestination = BackupFolderPath & "\" & Datestamp & ".dlx"
            My.Computer.FileSystem.CopyFile(txtDialuxPath.Text, FileDestination)
            Log("File " & FileDestination & " backed up.")

            'delete files
            DeleteOldBackups()

            'count number of filed backups
            CountBackupFiles()
            Exit Sub
        Catch
            Log("File backup failed." & vbNewLine & "ERROR DESCRIPTION:" & vbNewLine & Err.Description.ToString)
        End Try
    End Sub

    Public Sub ReadDialuxTitle()
        ' Retrieve Dialux Title
        Dim p As Process

        Try
            For Each p In Process.GetProcessesByName("dialux")

                Dim DialuxTitle As String
                DialuxTitle = p.MainWindowTitle.ToString
                Log("Read: " & DialuxTitle)
                Dim istart, iend As Integer

                'Remove Dialux V1.8 or blah blah
                istart = DialuxTitle.IndexOf("DIA")
                iend = DialuxTitle.IndexOf(" - ")
                DialuxTitle = DialuxTitle.Remove(istart, iend - istart + 3)
                'Old solution
                'DialuxTitle = Replace(DialuxTitle, "DIALux 4.8 - ", "")


                'Remove content between []
                istart = DialuxTitle.IndexOf("[") + 1
                iend = DialuxTitle.IndexOf("]")
                DialuxTitle = DialuxTitle.Remove(istart, iend - istart)

                'Remove []
                iend = DialuxTitle.IndexOf("]")
                DialuxTitle = DialuxTitle.Remove(iend - 4, 5)
                DialuxPath = DialuxTitle
                txtDialuxPath.Text = DialuxTitle
            Next

            'Check if file exists
            If My.Computer.FileSystem.FileExists(DialuxPath) = True Then
                lbExists.Text = "Status: File exists"
                Log("File found. Proceeding.")
                MakeBackupOfFile()
            Else
                lbExists.Text = "Status: File does not exist, nothing done. Do you have the letters [ or ] in the file name? Please remove them!"
                Log("Error reading file. Are you running dialux?")
            End If
        Catch
            Log("Error reading Dialux Window title! Please note the folder depth cannot be longer than 255 letters!" & vbNewLine & "ERROR DESCRIPTION:" & vbNewLine & Err.Description.ToString)
        End Try
    End Sub

    Public Sub SetBackupFolder()
        If My.Computer.FileSystem.DirectoryExists(txtBackupFolderPath.Text) = True Then
            lbBackupFolder.Text = "Status: Folder exists. Setting Saved."
            Log("Folder exists. Setting saved.")
            SaveSetting(My.Application.Info.Title, "Settings", "BackupFolderPath", txtBackupFolderPath.Text)
            'Save folder setting
        Else
            lbBackupFolder.Text = "Status: Folder does not exist. Please create it."
        End If
    End Sub

    Public Sub CheckRegistryBackupFolder()


        BackupFolderPath = GetSetting(My.Application.Info.Title, "Settings", "BackupFolderPath", "0")
        If BackupFolderPath = "0" Then
            My.Computer.FileSystem.CreateDirectory(AppFolder + "\Backup")
            txtBackupFolderPath.Text = AppFolder + "\Backup"
        Else
            txtBackupFolderPath.Text = BackupFolderPath
        End If
    End Sub



    Public Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        ReadDialuxTitle()
    End Sub

    Private Sub btReadDialuxTitle_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btReadDialuxTitle.Click
        ReadDialuxTitle()
    End Sub



    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Set icons
        Systray.Icon = Me.Icon
        Systray.Text = Me.Text

        'Perform regular operations
        CheckRegistryBackupFolder()
        SetBackupFolder()
        CountBackupFiles()
        Me.Visible = False
    End Sub

    Private Sub btReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btReset.Click
        txtBackupFolderPath.Text = AppFolder + "\Backup"
        SetBackupFolder()
    End Sub

    Private Sub btSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btSave.Click
        SetBackupFolder()
    End Sub

    Private Sub Systray_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Systray.Click

    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles Me.FormClosing
        Me.Visible = False
        e.Cancel = True
    End Sub


    Public Sub SystrayShow()
        ' Set the WindowState to normal if the form is minimized.
        Me.Activate()
        If Me.Visible = True Then
            Me.Visible = False
            Me.Hide()
        Else
            Me.Visible = True
            Me.Activate()
        End If
            Me.WindowState = FormWindowState.Normal
    End Sub

    Private Sub Systray_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Systray.MouseClick
        If e.Button = MouseButtons.Right Then
            ContextMenuStrip1.Show(MousePosition.X, MousePosition.Y)
            ContextMenuStrip1.Show()
        Else
            SystrayShow()
        End If
    End Sub

    Private Sub Systray_MouseDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Systray.MouseDoubleClick
        SystrayShow()
    End Sub

    Private Sub btClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btClose.Click
        Systray.Dispose()
        End
    End Sub

    Private Sub ExitToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Systray.Dispose()
        End
    End Sub

    Private Sub ShowToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ShowToolStripMenuItem.Click
        SystrayShow()
    End Sub

    Private Sub btOpenFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btOpenFolder.Click
        Shell("explorer " & BackupFolderPath, AppWinStyle.NormalFocus)
    End Sub

    Private Sub ReadDIALuxToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReadDIALuxToolStripMenuItem.Click
        ReadDialuxTitle()
    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs)
    End Sub

    Private Sub btClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btClear.Click
        txtLog.Text = ""
    End Sub
End Class
